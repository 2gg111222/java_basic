package 상속확인문제;

public class CoffeTruck {
		
	
	public void 짐() {
		System.out.println("커피를 운반하다.");

	}
	
}
